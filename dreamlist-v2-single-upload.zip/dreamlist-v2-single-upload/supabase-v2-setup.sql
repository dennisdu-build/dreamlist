create table if not exists public.dreamlist_app_state (
  id text primary key,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.dreamlist_app_state enable row level security;

drop policy if exists "dreamlist public read" on public.dreamlist_app_state;
drop policy if exists "dreamlist public insert" on public.dreamlist_app_state;
drop policy if exists "dreamlist public update" on public.dreamlist_app_state;

create policy "dreamlist public read"
on public.dreamlist_app_state
for select
to anon
using (true);

create policy "dreamlist public insert"
on public.dreamlist_app_state
for insert
to anon
with check (true);

create policy "dreamlist public update"
on public.dreamlist_app_state
for update
to anon
using (true)
with check (true);

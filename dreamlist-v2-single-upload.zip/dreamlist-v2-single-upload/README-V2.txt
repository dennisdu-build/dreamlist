梦想清单 V2 多人在线版上线说明

这版已经支持云端同步。配置成功后，不同手机和电脑访问同一个正式链接，写下的梦想会进入同一个云端数据表。

需要准备：
1. 一个 Supabase 项目。
2. 执行本文件夹里的 supabase-v2-setup.sql。
3. 在 app.js 里填入 Supabase 的 Project URL 和 anon public key。

配置位置：
app.js 顶部有这一段：

const CLOUD_CONFIG = {
  supabaseUrl: "",
  supabaseAnonKey: "",
};

把它改成：

const CLOUD_CONFIG = {
  supabaseUrl: "你的 Supabase Project URL",
  supabaseAnonKey: "你的 Supabase anon public key",
};

然后重新生成或上传 index.html。

重要说明：
1. 这是 V2 轻后台版，优点是上线快、成本低、可以多人共享数据。
2. 用户登录仍然是“输入名字”的轻登录，不是手机号/验证码登录。
3. 这版适合小范围社群使用；如果以后用户量变大，建议升级到 V3：正式账号体系、细粒度权限、每条数据独立存储。
4. 页面右上会显示“在线同步”。如果显示“本地模式”，说明还没有填 Supabase 配置；如果显示“云端未连接”，说明 URL/key/数据表权限需要检查。
